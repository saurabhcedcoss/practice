var products = [
  {
    id: "100",
    name: "iPhone 4S",
    brand: "Apple",
    os: "iOS",
  },
  {
    id: "101",
    name: "Moto X",
    brand: "Motorola",
    os: "Android",
  },
  {
    id: "102",
    name: "iPhone 6",
    brand: "Apple",
    os: "iOS",
  },
  {
    id: "103",
    name: "Samsung Galaxy S",
    brand: "Samsung",
    os: "Android",
  },
  {
    id: "104",
    name: "Google Nexus",
    brand: "ASUS",
    os: "Android",
  },
  {
    id: "105",
    name: "Surface",
    brand: "Microsoft",
    os: "Windows",
  },
];
var osdata = [];
function tblShow(prod) {
  var tbTr =
    "<tr><th>ID</th><th>Name</th><th>Brand</th><th>Operating System</th><th>Remove</th></tr>";
  prod.forEach((element) => {
    tbTr +=
      `<tr><td>` +
      element.id +
      `</td><td>` +
      element.name +
      `</td><td>` +
      element.brand +
      `</td><td>` +
      element.os +
      `</td>
	 <td><p class="cross">X</p></td> 
	  </tr>`;
  });
  $("#prTble").html(tbTr);
}
$(document).ready(function () {
  tblShow(products);

  //hide table row
  $(".cross").on("click", function rmv(ob) {
    $(this).parent().parent().toggle();
  });
  //sort by brand
  $("#sortBrand").change(function () {
    var slctBr = $(this).val();
    var slctOs = $("#sortOs").children("option:selected").val();
    console.log(slctOs);
    if (
      (slctBr == "Apple" && slctOs == "Android") ||
      (slctBr == "Apple" && slctOs == "Windows") ||
      (slctBr == "Microsoft" && slctOs == "Android") ||
      (slctBr == "Microsoft" && slctOs == "iOS")
    ) {
      
      brdata = [];
    } else {
      
      brdata = products.filter(function (e) {
        return slctBr == e.brand;
      });
    }
    tblShow(brdata);
    // if (slctBr == "Apple" && ) {
    //   $("#sortOs option[value='Android'],option[value='Windows']").hide();
    //   $("#sortOs option[value='iOS']").show();
    // } else if (slctBr == "Microsoft") {
    //   $("#sortOs option[value='Android'],option[value='iOS']").hide();
    //   $("#sortOs option[value='Windows']").show();
    // } else if (slctBr == "Motorola" || "Samsung" || "ASUS") {
    //   $("#sortOs option[value='Windows'],option[value='iOS']").hide();
    //   $("#sortOs option[value='Android']").show();
    // } else if (slctBr == "brands") {
    //   $(
    //     "#sortOs option[value='Android'],option[value='iOS'],option[value='Windows']"
    //   ).show();
    //   $(
    //     "#sortBrand option[value='Apple'],option[value='Motorola'],option[value='Samsung'],option[value='ASUS'],option[value='Microsoft']"
    //   ).show();
    // }
  });
  //sort by os
  $("#sortOs").change(function () {
    var slctOs = $(this).val();
    var slctBr = $("#sortBrand").children("option:selected").val();
    console.log(slctBr);
    if (
      (slctOs == "iOS" && slctBr == "Motorola") ||
      (slctOs == "iOS" && slctBr == "Samsung") ||
      (slctOs == "iOS" && slctBr == "ASUS") ||
      (slctOs == "iOS" && slctBr == "Microsoft")
    ) {
      
      osdata = [];
    } else {
      osdata = products.filter(function (e) {
        return slctOs == e.os;
      });
    }
    tblShow(osdata);
    // if (slctOs == "Android") {
    //   $("#sortBrand option[value='Apple'],option[value='Microsoft']").hide();
    //   $(
    //     "#sortBrand option[value='Motorola'],option[value='Samsung'],option[value='ASUS']"
    //   ).show();
    // } else if (slctOs == "iOS") {
    //   $(
    //     "#sortBrand option[value='Microsoft'],option[value='Motorola'],option[value='Samsung'],option[value='ASUS']"
    //   ).hide();
    //   $("#sortBrand option[value='Apple']").show();
    // } else if (slctOs == "Windows") {
    //   $(
    //     "#sortBrand option[value='Apple'],option[value='Motorola'],option[value='Samsung'],option[value='ASUS']"
    //   ).hide();
    //   $("#sortBrand option[value='Microsoft']").show();
    // } else if (slctOs == "os") {
    //   $(
    //     "#sortBrand option[value='Apple'],option[value='Motorola'],option[value='Samsung'],option[value='ASUS'],option[value='Microsoft']"
    //   ).show();
    //   $(
    //     "#sortOs option[value='Android'],option[value='iOS'],option[value='Windows']"
    //   ).show();
    // }
  });
  //search on keyup
  $("#srch").on("keyup", function () {
    var value = $(this).val().toLowerCase();
    $("#prTble tr").filter(function () {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
  });
});
